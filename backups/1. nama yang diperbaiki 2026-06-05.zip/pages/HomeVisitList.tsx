
import React, { useState, useMemo } from 'react';
import { Student, Teacher, HomeVisit, SchoolProfile, Appointment, UserRole, CounselorProfileData, Rombel } from '../types';
import Letterhead from '../components/Letterhead';
import { jsPDF } from 'jspdf';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, PieChart, Pie, Legend } from 'recharts';
import autoTable from 'jspdf-autotable';
import { drawLetterhead } from '../utils/pdfHelper';
import { generateLetterNumber } from '../utils/letterGenerator';

interface HomeVisitListProps {
  students: Student[];
  rombels: Rombel[];
  teachers: Teacher[];
  homeVisits: HomeVisit[];
  setHomeVisits: React.Dispatch<React.SetStateAction<HomeVisit[]>>;
  setAppointments: React.Dispatch<React.SetStateAction<Appointment[]>>;
  schoolProfile: SchoolProfile;
  notify: (msg: string, type?: 'success' | 'error' | 'info') => void;
  userRole?: UserRole;
  counselorProfile?: CounselorProfileData;
  currentUser?: any;
}

const HomeVisitList: React.FC<HomeVisitListProps> = ({ students, rombels, teachers, homeVisits, setHomeVisits, setAppointments, schoolProfile, notify, userRole, counselorProfile, currentUser }) => {
  const [isAddMode, setIsAddMode] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [selectedVisit, setSelectedVisit] = useState<HomeVisit | null>(null);
  const [selectedClassString, setSelectedClassString] = useState(''); // NEW: State untuk filter kelas
  const [currentNoSurat, setCurrentNoSurat] = useState<string>('');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 50;
  
  const [formData, setFormData] = useState<Partial<HomeVisit>>({
    studentId: '',
    date: new Date().toISOString().split('T')[0],
    reason: '',
    findings: '',
    solutions: '',
    followUp: '',
    parentName: '',
    teacherIds: []
  });

  const isPrincipal = userRole === 'principal';

  // --- LOGIKA DAFTAR KELAS DARI DATABASE SISWA ---
  const uniqueStudentClasses = useMemo(() => {
    const classSet = new Set<string>();
    let sourceRombels = rombels || [];

    if (userRole === 'counselor' && currentUser && teachers) {
      const myTeacherProfile = teachers.find(t => t.name === currentUser.name);
      if (myTeacherProfile) {
        const myRombelIds = new Set<string>();
        sourceRombels.filter(r => r.homeroomTeacherId === myTeacherProfile.id).forEach(r => myRombelIds.add(r.id));

        const gradeMatch = myTeacherProfile.assignment.match(/Tingkat (X|XI|XII)/i);
        if (gradeMatch) {
          const targetGrade = gradeMatch[1].toUpperCase();
          sourceRombels.filter(r => r.grade === targetGrade).forEach(r => myRombelIds.add(r.id));
        }
        sourceRombels = sourceRombels.filter(r => myRombelIds.has(r.id));
      } else {
        sourceRombels = [];
      }
    }

    sourceRombels.forEach(r => {
        const fullClassName = r.name.trim();
        if (fullClassName) {
            classSet.add(fullClassName);
        }
    });
    // Sortir secara alfabetis agar rapi (X dulu, lalu XI, dst)
    return Array.from(classSet).sort((a, b) => {
        const getGradeWeight = (name: string) => {
            if (name.startsWith('X ')) return 1;
            if (name.startsWith('XI ')) return 2;
            if (name.startsWith('XII ')) return 3;
            return 4;
        };
        const weightA = getGradeWeight(a);
        const weightB = getGradeWeight(b);
        if (weightA !== weightB) return weightA - weightB;
        return a.localeCompare(b);
    });
  }, [rombels, userRole, currentUser, teachers]);

  // --- FILTER SISWA UNTUK DROPDOWN ---
  const filteredStudentsDropdown = useMemo(() => {
    let list = students.filter(s => s.status === 'Aktif');
    
    if (selectedClassString) {
        list = list.filter(s => `${s.grade} ${s.class}`.trim() === selectedClassString);
    }
    
    return list.sort((a, b) => a.name.localeCompare(b.name));
  }, [students, selectedClassString]);

  const getStudent = (id: string) => (students || []).find(s => s.id === id);

  const handleOpenPreview = async (visit: HomeVisit) => {
    setSelectedVisit(visit);
    setCurrentNoSurat('Sedang membuat nomor surat...');
    const noSurat = await generateLetterNumber('HomeVisit', visit.id, schoolProfile);
    setCurrentNoSurat(noSurat);
  };


  const getInitials = (name: string) => {
    if (!name) return '-';
    return name.trim().split(/\s+/).map(w => w[0].toUpperCase()).join('.') + '.';
  };

  const sanitizeHomeVisit = (id: string) => {
    setHomeVisits(prev => prev.map(v => 
      v.id === id && v.findings !== '[DATA TEMUAN DIHAPUS]'
        ? { ...v, findings: '[DATA TEMUAN DIHAPUS]', parentName: getInitials(v.parentName) } 
        : v
    ));
  };

  const handleClosePreview = () => {
    if (selectedVisit) {
      sanitizeHomeVisit(selectedVisit.id);
    }
    setSelectedVisit(null);
  };

  const syncToAgenda = (visit: HomeVisit) => {
    const student = getStudent(visit.studentId);
    const appointmentId = `apt-sync-${visit.id}`;
    const newApt: Appointment = {
      id: appointmentId,
      studentId: visit.studentId,
      studentName: getInitials(student?.name || 'Siswa'),
      date: visit.date.split('T')[0],
      time: new Date().toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' }),
      reason: `Kunjungan Rumah: ${visit.parentName}`,
      status: 'Selesai'
    };
    setAppointments(prev => {
      const filtered = prev.filter(a => a.id !== appointmentId);
      return [newApt, ...filtered];
    });
  };

  const handleExportAll = () => {
    const myVisits = (homeVisits || []);
    if (myVisits.length === 0) return;
    const doc = new jsPDF();
    const startY = drawLetterhead(doc, schoolProfile, 'p');

    doc.setFont("times", "bold");
    doc.setFontSize(14);
    doc.text(`DATA KUNJUNGAN RUMAH`, 105, startY + 5, { align: 'center' });

    const tableData = myVisits.map(v => [
      new Date(v.date).toLocaleDateString('id-ID'),
      getInitials(getStudent(v.studentId)?.name || 'Siswa'),
      v.parentName,
      v.reason
    ]);
    autoTable(doc, { head: [['Tanggal', 'Siswa (Inisial)', 'Orang Tua', 'Alasan']], body: tableData, startY: startY + 15 });
    doc.save(`Database_HomeVisit_${Date.now()}.pdf`);
    notify("Database home visit berhasil diunduh.");
  };

  const handleDownloadSingle = (v: HomeVisit) => {
    if (v.findings === '[DATA TEMUAN DIHAPUS]') {
      notify("Maaf, data detail laporan ini sudah dihapus demi privasi.", "error");
      return;
    }

    const doc = new jsPDF();
    const student = getStudent(v.studentId);
    const studentFullName = student?.name || '';
    
    const startY = drawLetterhead(doc, schoolProfile, 'p');

    doc.setFontSize(12); doc.setFont("times", "bold");
    doc.text("BERITA ACARA KUNJUNGAN RUMAH (HOME VISIT)", 105, startY + 5, { align: 'center' });
    doc.setFontSize(10); doc.text(`Nomor: ${currentNoSurat}`, 105, startY + 10, { align: 'center' });
    
    autoTable(doc, {
      startY: startY + 18, theme: 'plain', styles: { font: 'times', fontSize: 11, cellPadding: 1 },
      columnStyles: { 0: { cellWidth: 50 }, 1: { cellWidth: 5 }, 2: { cellWidth: 'auto' } },
      body: [
        ["Nama Siswa (Inisial)", ":", getInitials(studentFullName)],
        ["Orang Tua/Wali", ":", v.parentName],
        ["Hari, Tanggal", ":", new Date(v.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })],
        ["Alasan Kunjungan", ":", v.reason]
      ],
    });

    let currentY = (doc as any).lastAutoTable.finalY + 10;
    doc.setFont("times", "bold"); doc.text("I. TEMUAN & EVALUASI LAPANGAN", 20, currentY);
    doc.setFont("times", "normal");
    const splitFindings = doc.splitTextToSize(v.findings, 170);
    doc.text(splitFindings, 20, currentY + 7, { align: 'justify' });
    currentY += (splitFindings.length * 5) + 15;

    doc.setFont("times", "bold"); doc.text("II. KESEPAKATAN & TINDAK LANJUT", 20, currentY);
    doc.setFont("times", "normal");
    const splitSolutions = doc.splitTextToSize(v.solutions, 170);
    doc.text(splitSolutions, 20, currentY + 7, { align: 'justify' });
    
    currentY += (splitSolutions.length * 5) + 30;
    if (currentY > 230) { doc.addPage(); currentY = 30; }

    doc.setFont("times", "normal");
    doc.text("Mengetahui,", 40, currentY);
    doc.text("Kepala Sekolah", 40, currentY + 5);
    const placeDate = `${schoolProfile.city || '...............'}, ${new Date(v.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}`;
    doc.text(placeDate, 140, currentY);
    doc.text("Guru BK / Konselor,", 140, currentY + 5);
    doc.setFont("times", "bold");
    doc.text(schoolProfile.principalName, 40, currentY + 35);
    doc.text(v.counselorName || counselorProfile?.name || schoolProfile.counselorName, 140, currentY + 35);
    doc.setFont("times", "normal"); doc.setFontSize(8);
    doc.text(`NIP. ${schoolProfile.principalNip}`, 40, currentY + 40);
    doc.text(`NIP. ${counselorProfile?.nip || schoolProfile.counselorNip}`, 140, currentY + 40);

    doc.save(`Berita_Acara_HomeVisit_${getInitials(studentFullName).replace(/\./g, '')}.pdf`);
    notify("Berita acara berhasil diunduh. Data sensitif kini disamarkan.");
    sanitizeHomeVisit(v.id);
  };

  const handleSaveVisit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.studentId || !formData.reason || !formData.date) return;
    const activeCounselor = counselorProfile?.name || schoolProfile.counselorName;
    const student = students.find(s => s.id === formData.studentId);
    let savedVisit: HomeVisit;
    if (editingId) {
      savedVisit = { ...formData, id: editingId, counselorName: activeCounselor } as HomeVisit;
      setHomeVisits(prev => (prev || []).map(v => v.id === editingId ? savedVisit : v));
      notify("Laporan diperbarui & Agenda disinkronkan.");
    } else {
      savedVisit = { id: `hv-${Date.now()}`, ...formData as HomeVisit, counselorName: activeCounselor, gradeAtTime: student?.grade };
      setHomeVisits(prev => [savedVisit, ...(prev || [])]);
      notify("Laporan baru disimpan & Agenda disinkronkan.");
    }
    syncToAgenda(savedVisit);
    setIsAddMode(false);
    setEditingId(null);
    handleOpenPreview(savedVisit);
    setSelectedClassString(''); 
  };

  const myVisits = (homeVisits || []).filter(v => {
    const student = getStudent(v.studentId);
    if (student) {
      return !v.gradeAtTime || v.gradeAtTime === student.grade;
    }
    return true;
  });

  const totalPages = Math.ceil(myVisits.length / itemsPerPage);
  const paginatedVisits = useMemo(() => {
    const start = (currentPage - 1) * itemsPerPage;
    return myVisits.slice(start, start + itemsPerPage);
  }, [myVisits, currentPage]);

  React.useEffect(() => {
    setCurrentPage(1);
  }, [isAddMode]);

  return (
    <div className="space-y-6 animate-in slide-in-from-bottom-4 duration-500 pb-10">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-4 no-print">
        <div><h2 className="text-2xl font-bold text-slate-900">Kunjungan Rumah (Home Visit)</h2><p className="text-slate-500 text-sm">Dokumentasi hasil kunjungan lapangan dengan protokol privasi otomatis.</p></div>
        <div className="flex gap-2">
          {!isAddMode && (homeVisits || []).length > 0 && !isPrincipal && (
            <button onClick={handleExportAll} className="bg-white border border-slate-200 text-slate-600 px-5 py-2.5 rounded-xl text-sm font-bold shadow-sm hover:bg-slate-50 flex items-center gap-2 transition-all">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
              Unduh Rekap
            </button>
          )}
          {!isAddMode && userRole !== 'principal' && userRole !== 'supervisor' && (
            <button onClick={() => { setFormData({...formData, date: new Date().toISOString().split('T')[0]}); setIsAddMode(true); setSelectedClassString(''); }} className="bg-teal-600 text-white px-6 py-2.5 rounded-xl text-sm font-bold shadow-lg shadow-teal-100 hover:bg-teal-700 transition-all flex items-center gap-2">
              <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M5 12h14"/><path d="M12 5v14"/></svg>
              Buat Laporan Baru
            </button>
          )}
        </div>
      </header>

      {isAddMode ? (
        <div className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm p-10 max-w-5xl mx-auto no-print space-y-6">
           <div className="flex justify-between items-center mb-4">
              <h3 className="text-xl font-black text-slate-800">{editingId ? 'Edit Laporan Home Visit' : 'Input Home Visit Baru'}</h3>
           </div>
           
           {/* Section Filter Kelas & Siswa */}
           <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
             <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Pilih Kelas (Opsional)</label>
                <select 
                    className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 text-sm font-bold outline-none focus:ring-4 focus:ring-teal-500/10"
                    value={selectedClassString}
                    onChange={(e) => {
                        setSelectedClassString(e.target.value);
                        setFormData({...formData, studentId: ''}); // Reset student
                    }}
                >
                    <option value="">-- Semua Kelas --</option>
                    {uniqueStudentClasses.map((cls, idx) => (
                        <option key={idx} value={cls}>{cls}</option>
                    ))}
                </select>
              </div>

              <div className="space-y-1.5 md:col-span-2">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Pilih Siswa</label>
                <select required className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 text-sm font-bold outline-none focus:ring-4 focus:ring-teal-500/10" value={formData.studentId} onChange={e => setFormData({...formData, studentId: e.target.value})}>
                  <option value="">-- Pilih Siswa --</option>
                        {filteredStudentsDropdown.map(s => (
                            <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                </select>
                {filteredStudentsDropdown.length === 0 && (
                    <p className="text-[9px] text-slate-400 italic px-1 mt-1">Tidak ada siswa ditemukan di kelas yang dipilih.</p>
                )}
              </div>
           </div>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Tanggal Kunjungan</label>
                <input required type="date" className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 text-sm font-bold outline-none focus:ring-4 focus:ring-teal-500/10" value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Nama Orang Tua / Wali yang Ditemui</label>
                <input required className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-3 text-sm font-bold outline-none focus:ring-4 focus:ring-teal-500/10" placeholder="Nama Ibu/Ayah/Wali..." value={formData.parentName} onChange={e => setFormData({...formData, parentName: e.target.value})} />
              </div>
           </div>
           
           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Alasan Kunjungan</label>
                <textarea required className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold h-24 resize-none" value={formData.reason} onChange={e => setFormData({...formData, reason: e.target.value})} />
              </div>
              <div className="space-y-1.5">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Temuan Lapangan (Akan dihapus setelah cetak PDF)</label>
                <textarea required className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold h-24 resize-none" value={formData.findings} onChange={e => setFormData({...formData, findings: e.target.value})} />
              </div>
           </div>
           <div className="space-y-1.5">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest px-1">Solusi & Tindak Lanjut</label>
              <textarea required className="w-full bg-slate-50 border border-slate-200 rounded-2xl px-5 py-4 text-sm font-bold h-24 resize-none" value={formData.solutions} onChange={e => setFormData({...formData, solutions: e.target.value})} />
           </div>
           <div className="flex gap-4 pt-6">
              <button type="button" onClick={() => { setIsAddMode(false); setSelectedClassString(''); }} className="flex-1 py-4 text-sm font-bold text-slate-400 uppercase tracking-widest">Batal</button>
              <button onClick={handleSaveVisit} className="flex-[2] py-4 bg-teal-600 text-white rounded-2xl text-xs font-black uppercase tracking-widest shadow-xl active:scale-95">Simpan dan Pratinjau</button>
           </div>
        </div>
      ) : userRole === 'supervisor' ? (
        <div className="bg-white p-8 rounded-[3rem] border border-slate-100 shadow-sm">
           <h3 className="text-lg font-black text-slate-800 mb-6">Statistik Kunjungan Rumah per Konselor</h3>
           <div className="h-[400px]">
              <ResponsiveContainer width="100%" height="100%">
                 <PieChart>
                    <Pie 
                      data={Object.entries(homeVisits.reduce((acc, curr) => {
                        const name = curr.counselorName || 'Tidak Diketahui';
                        acc[name] = (acc[name] || 0) + 1;
                        return acc;
                      }, {} as Record<string, number>)).map(([name, value]) => ({ name, value }))}
                      cx="50%" 
                      cy="50%" 
                      innerRadius={80} 
                      outerRadius={120} 
                      paddingAngle={5} 
                      dataKey="value"
                      nameKey="name"
                    >
                       {Object.entries(homeVisits.reduce((acc, curr) => {
                        const name = curr.counselorName || 'Tidak Diketahui';
                        acc[name] = (acc[name] || 0) + 1;
                        return acc;
                      }, {} as Record<string, number>)).map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={['#0d9488', '#0f766e', '#115e59', '#134e4a'][index % 4]} />
                       ))}
                    </Pie>
                    <Tooltip contentStyle={{borderRadius: '16px', border: 'none', boxShadow: '0 10px 15px rgba(0,0,0,0.1)', fontSize: '11px', fontWeight: 700}} />
                    <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontSize: '12px', fontWeight: 'bold' }} />
                 </PieChart>
              </ResponsiveContainer>
           </div>
        </div>
      ) : (
        <div className="space-y-6 no-print">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {paginatedVisits.map(visit => {
              const student = getStudent(visit.studentId);
              const sanitized = visit.findings === '[DATA TEMUAN DIHAPUS]';
              return (
                <div key={visit.id} className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-xl transition-all cursor-pointer group flex flex-col min-h-[280px]" onClick={() => handleOpenPreview(visit)}>
                  <div className="flex justify-between items-start mb-6">
                      <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-black border ${sanitized ? 'bg-slate-50 text-slate-400 border-slate-200' : 'bg-teal-50 text-teal-600 border-teal-100'}`}>
                        {student?.name.charAt(0) || 'S'}
                      </div>
                      <span className={`px-2 py-1 rounded-lg text-[9px] font-black uppercase ${sanitized ? 'bg-emerald-50 text-emerald-600' : 'bg-teal-50 text-teal-600'}`}>
                        {sanitized ? 'Arsip Aman' : 'Kunjungan'}
                      </span>
                  </div>
                  <h4 className="font-bold text-slate-800 text-base mb-1 truncate">{getInitials(student?.name || 'Siswa')}</h4>
                  <p className="text-[10px] text-slate-400 font-bold uppercase mb-2 truncate">Wali: {visit.parentName}</p>
                  <p className="text-[9px] text-slate-300 font-medium truncate italic mb-4">Konselor: {visit.counselorName || '-'}</p>
                  <p className="text-xs text-slate-500 line-clamp-3 italic mb-4 leading-relaxed">
                    {sanitized ? "Detail temuan lapangan disamarkan untuk perlindungan privasi." : `"${visit.reason}"`}
                  </p>
                  <div className="flex justify-between items-center text-[10px] font-black text-slate-400 mt-auto pt-4 border-t border-slate-50">
                      <span>{new Date(visit.date).toLocaleDateString('id-ID')}</span>
                      <span className="text-teal-600 group-hover:translate-x-1 transition-all uppercase">Lihat Laporan →</span>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Pagination Controls */}
          {totalPages > 1 && (
            <div className="flex items-center justify-between bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm">
              <p className="text-xs text-slate-500 font-medium">
                Menampilkan <span className="font-bold text-slate-800">{(currentPage - 1) * itemsPerPage + 1}</span> - <span className="font-bold text-slate-800">{Math.min(currentPage * itemsPerPage, myVisits.length)}</span> dari <span className="font-bold text-slate-800">{myVisits.length}</span> laporan
              </p>
              <div className="flex gap-1">
                <button 
                  onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
                  disabled={currentPage === 1}
                  className="p-2 rounded-lg border bg-white text-slate-600 disabled:opacity-50 hover:bg-slate-50 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="15 18 9 12 15 6"/></svg>
                </button>
                <div className="flex gap-1 mx-2">
                  {[...Array(totalPages)].map((_, i) => (
                    <button
                      key={i}
                      onClick={() => setCurrentPage(i + 1)}
                      className={`w-8 h-8 rounded-lg text-xs font-bold transition-all ${currentPage === i + 1 ? 'bg-teal-600 text-white shadow-md' : 'bg-white text-slate-600 border'}`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
                <button 
                  onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
                  disabled={currentPage === totalPages}
                  className="p-2 rounded-lg border bg-white text-slate-600 disabled:opacity-50 hover:bg-slate-50 transition-colors"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polyline points="9 18 15 12 9 6"/></svg>
                </button>
              </div>
            </div>
          )}

          {myVisits.length === 0 && (
            <div className="py-20 text-center bg-white rounded-[3rem] border border-dashed border-slate-200 text-slate-400 italic">Belum ada laporan kunjungan rumah.</div>
          )}
        </div>
      )}

      {selectedVisit && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300 no-print">
          <div className="bg-white rounded-[3rem] w-full max-w-4xl max-h-[92vh] shadow-2xl overflow-hidden flex flex-col border border-white/20">
             <header className="p-8 bg-teal-600 text-white flex justify-between items-center shrink-0">
               <div>
                  <h3 className="text-xl font-black">Pratinjau Berita Acara Home Visit</h3>
                  <p className="text-teal-100 text-xs mt-1">Siswa: {getInitials(getStudent(selectedVisit.studentId)?.name || 'Siswa')}</p>
               </div>
               <div className="flex gap-2">
                 {!isPrincipal && userRole !== 'supervisor' && selectedVisit.findings !== '[DATA TEMUAN DIHAPUS]' && (
                   <button 
                      onClick={() => {
                        setFormData({
                          studentId: selectedVisit.studentId,
                          date: selectedVisit.date,
                          reason: selectedVisit.reason,
                          parentName: selectedVisit.parentName,
                          findings: selectedVisit.findings,
                          solutions: selectedVisit.solutions,
                          documentation: selectedVisit.documentation
                        });
                        setEditingId(selectedVisit.id);
                        setIsAddMode(true);
                        setSelectedVisit(null);
                      }}
                      className="bg-white/20 hover:bg-white/30 text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all"
                   >
                      <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
                      Edit
                   </button>
                 )}
                 <button onClick={() => handleDownloadSingle(selectedVisit)} disabled={selectedVisit.findings === '[DATA TEMUAN DIHAPUS]'} className={`bg-white/20 hover:bg-white/30 text-white px-4 py-2.5 rounded-xl text-xs font-bold flex items-center gap-2 transition-all ${selectedVisit.findings === '[DATA TEMUAN DIHAPUS]' ? 'opacity-50 cursor-not-allowed' : ''}`}>
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" x2="12" y1="15" y2="3"/></svg>
                    Simpan PDF
                 </button>
                 <button onClick={handleClosePreview} className="p-2.5 hover:bg-white/10 rounded-xl transition-all"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button>
               </div>
             </header>
             <div className="flex-1 overflow-y-auto p-12 bg-slate-100 custom-scrollbar">
                <div id="print-area" className="bg-white shadow-xl mx-auto w-full max-w-[800px] border border-slate-100 p-12 min-h-[1000px]">
                   <Letterhead profile={schoolProfile} />
                   <div className="p-8 space-y-8 font-serif text-slate-900 leading-relaxed text-sm text-justify">
                      <div className="text-center space-y-1"><h2 className="text-lg font-bold uppercase underline">BERITA ACARA KUNJUNGAN RUMAH</h2><p>Nomor: {currentNoSurat}</p></div>
                      <div className="space-y-4 pt-4">
                         <p>Telah dilaksanakan kunjungan rumah (home visit) pada hari ini:</p>
                         <table className="w-full ml-4">
                            <tbody>
                               <tr><td className="w-40 py-1">Hari, Tanggal</td><td className="w-4">:</td><td className="font-bold">{new Date(selectedVisit.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}</td></tr>
                               <tr><td className="w-40 py-1">Nama Siswa (Inisial)</td><td className="w-4">:</td><td className="font-bold uppercase">{getInitials(getStudent(selectedVisit.studentId)?.name || 'Siswa')}</td></tr>
                               <tr><td className="py-1">Orang Tua / Wali</td><td>:</td><td className="font-bold">{selectedVisit.parentName}</td></tr>
                            </tbody>
                         </table>
                         <div className="space-y-6 pt-4">
                            <div><p className="font-bold">I. Temuan Lapangan:</p><div className={`p-4 rounded-lg mt-1 border italic ${selectedVisit.findings === '[DATA TEMUAN DIHAPUS]' ? 'bg-rose-50 border-rose-100 text-rose-500' : 'bg-slate-50 border-slate-100 text-slate-700'}`}>"{selectedVisit.findings}"</div></div>
                            <div><p className="font-bold">II. Solusi & Rencana Tindak Lanjut:</p><div className="p-4 bg-slate-50 italic rounded-lg mt-1 border">"{selectedVisit.solutions}"</div></div>
                         </div>
                      </div>
                      <div className="pt-20 grid grid-cols-2 gap-12 text-center">
                        <div className="space-y-20">
                          <p>Mengetahui,<br/>Kepala Sekolah</p>
                          <div><p className="font-bold underline uppercase">{schoolProfile.principalName}</p><p className="text-[10px] font-sans">NIP. {schoolProfile.principalNip}</p></div>
                        </div>
                        <div className="space-y-20">
                          <p>{schoolProfile.city || "...................."}, {new Date(selectedVisit.date).toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' })}<br/>Guru BK / Konselor,</p>
                          <div><p className="font-bold underline uppercase">{selectedVisit.counselorName || counselorProfile?.name || schoolProfile.counselorName}</p><p className="text-[10px] font-sans">NIP. {counselorProfile?.nip || schoolProfile.counselorNip}</p></div>
                        </div>
                      </div>
                   </div>
                </div>
             </div>
             <div className="p-8 border-t border-slate-100 bg-white flex justify-end no-print shrink-0">
                <button onClick={handleClosePreview} className="px-12 py-4 bg-slate-900 text-white rounded-[1.5rem] text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 transition-colors">Tutup & Terapkan Privasi</button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default HomeVisitList;
